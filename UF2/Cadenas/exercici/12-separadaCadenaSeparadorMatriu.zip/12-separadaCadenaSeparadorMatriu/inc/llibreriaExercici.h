#ifndef D8E5564E_A998_46E6_9A70_0B73488F1AF3
#define D8E5564E_A998_46E6_9A70_0B73488F1AF3
//incloure les llibreries que es necessiten
#include <stdbool.h>

#define MAXPARAULES 4
#define MIDA 50
#define MARCA '\0'
void separa2(char [],int ,char [][MIDA]);
void separaParaulaSeparador(char [],int ,char ,char [],int *);


#endif /* D8E5564E_A998_46E6_9A70_0B73488F1AF3 */
