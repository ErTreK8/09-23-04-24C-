#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>
#include <string.h>
#include <stdbool.h>
#include "rlutil.h"
#include "llibreriaPropia.h"
#include "llibreriaExercici.h"

int preguntaOpcio()
{
    char  opcionsMenu [SORTIR][40] = {  "Afegir alumne",
                                        "Modificar alumne",
                                        "Eliminar alumne",
                                        "Inserir notes",
                                        "Calcular Nota",
                                        "Mostrar alumnes",
                                        "Sortir"};

    int op;
    printf("MENU:\n");
    for (int i = 0; i < SORTIR; i++)
    {
        printf("%d.- %s\n",i+1,opcionsMenu[i]);
    }

    printf("\nIntrodueix quina opcio vols fer? [%d-%d]",1,SORTIR);
    op=demanaNumEntreRangInt(AFEGIR,SORTIR);
    return op;
}
void omplirAlumne(ALUMNE classe[],int *qttAlumnes)
{
    if (*qttAlumnes==MAXALUMNES)
    {
        comentaris(1);
    }
    else
    {
        classe[*qttAlumnes]=altaUnAlumne();
        if (existeixAlumne(classe,*qttAlumnes)==false)
            (*qttAlumnes)++;
        else
            comentaris(3);
    }
}
void comentaris(int num)
{
    printf("\n");
    switch (num)
    {
        case 1: printf("Classe plena"); break;
        case 2: printf("Classe buida"); break;
        case 3: printf("Alumne ja donat d'alta en el sistema"); break;
    }
    printf("\n");
}

ALUMNE altaUnAlumne()
{
    ALUMNE nou;
    printf("Introdueix el nom de l'alumne: ");
    entrarCadena(nou.nom, sizeof(nou.nom));

    nou.qttNotesALumne=0;
    return nou;
}
bool existeixAlumne(ALUMNE classe[], int qttA)
{
    bool existeix = false;
    int i = 0;
    while (existeix == false && i < qttA)
    {
        if (strcmpi(classe[i].nom, classe[qttA].nom) == 0)
        {
            existeix = true;
        }
        else
        {
            i++;
        }
    }
    return existeix;
}
void pinta(ALUMNE classe[],int qttAlumnes)
{
    if (qttAlumnes==0)
    {
        comentaris(2);
    }
    else
    {
        for (int i=0;i<qttAlumnes;i++)
        {
            pintaUnAlumne(classe[i]);
        }
    }
}
void pintaUnAlumne(ALUMNE un)
{
    printf("\n%s",un.nom);
}
