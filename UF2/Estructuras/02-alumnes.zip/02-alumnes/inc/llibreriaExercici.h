#ifndef D8E5564E_A998_46E6_9A70_0B73488F1AF3
#define D8E5564E_A998_46E6_9A70_0B73488F1AF3
//incloure les llibreries que es necessiten
#include <stdbool.h>

#define FICADENA '\0'
#define SALTLINIA '\n'
#define ESPAI ' '
#define MIDA 30
#define TOTALUF 19
#define MAXALUMNES 30

enum OPCIONSMENU
{
    AFEGIR=1,
    MODIFICAR,
    ELIMINAR,
    INSERIR,
    CALCULARNOTA,
    MOSTRAR,
    SORTIR
};


typedef struct
{
    char nomUF[10];
    int nota;
}NOTES;

typedef struct
{
    char nom[MIDA];
    NOTES qualificacions[TOTALUF];
    int qttNotesALumne;
}ALUMNE;


int preguntaOpcio();
ALUMNE altaUnAlumne();
void omplirAlumne(ALUMNE [],int *);
void comentaris(int );
bool existeixAlumne(ALUMNE [], int );
void pinta(ALUMNE [],int );
void pintaUnAlumne(ALUMNE );


#endif /* D8E5564E_A998_46E6_9A70_0B73488F1AF3 */
