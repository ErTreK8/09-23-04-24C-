#ifndef __LLIBRERIA_PROPIA_H__
#define __LLIBRERIA_PROPIA_H__
//incloure les llibreries que es necessiten
#include <stdbool.h>
    void acabament (void);
#endif