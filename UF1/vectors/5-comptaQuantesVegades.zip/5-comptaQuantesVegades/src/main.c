#include <stdio.h>
#include <stdlib.h>
#include <time.h>  
#include <windows.h>
#include <string.h>
#include <stdbool.h>
#include "rlutil.h"
#include "llibreriaPropia.h"
#include "llibreriaExercici.h"
/*1.	(NotaNumericaaLLetres) Fer un programa que demani una nota compresa entre 1 i 10 i
 posteriorment transformi la nota en la seva qualificaci� en lletres. */


int main(){
	SetConsoleOutputCP(CP_UTF8);
	SetConsoleCP(CP_UTF8);
	srand(time(NULL));

	int numCont[MAXVECTOR];
	int numUsu;
	int qtt=0;
	int pos;

	
	do
	{
		printf("Introduix un numero: ");
		numUsu=demanaNumEntreRangInt(SORTIR,MAXNUM);
		if (numUsu!=SORTIR)
		{
			pos=posicio2(numCont,qtt,numUsu);
			if (pos==-1)
			{
				//nou numero
				afegirNouNumero(&numCont[qtt],&numCont[qtt+1],&qtt,numUsu);
				//afegirNouNumero(numCont,&qtt,numUsu);
			}
			else
			{
				//numero repetit
				incrementarContador(&numCont[pos+1]);
			}
		}
	} while (numUsu!=SORTIR);
	
	mostrarResultat(numCont,qtt);

	

	acabament();
	return 0;
}
