#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>
#include <string.h>
#include <stdbool.h>
#include "rlutil.h"
#include "llibreriaPropia.h"
#include "llibreriaExercici.h"

int posicio2(int v[],int qtt,int numCerca)
{
    int i=0, pos=-1;
    while(i<qtt && pos==-1)
    {
        if(v[i]==numCerca)
        {
            pos=i;
        }
        else
        {
            i=i+2;
        }
    }
    return pos;
}

void afegirNouNumero(int *casella1,int *casella2,int *qtt,int numUsu)
{
    *casella1=numUsu;
    *casella2=1;
    (*qtt)=(*qtt)+2;
}

void incrementarContador(int *casella)
{
    (*casella)++;
}


void mostrarResultat(int numCont[],int qtt)
{
    int pos;
    int cont=0;
    /*for (int i=MINNUM;i<MAXNUM && cont<qtt/2;i++)
    {
        pos=posicio2(numCont,qtt,i);
        if (pos!=-1)
        {
            printf("[%d]:%d\n",i,numCont[pos+1]);
            cont++;
        }
    }*/
    int i=MINNUM;
    while (i<MAXNUM && cont<qtt/2)
    {
        pos=posicio2(numCont,qtt,i);
        if (pos!=-1)
        {
            printf("[%d]:%d\n",i,numCont[pos+1]);
            cont++;
        }
        i++;
    }
}