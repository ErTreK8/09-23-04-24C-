#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>
#include <string.h>
#include <stdbool.h>
#include "rlutil.h"
#include "llibreriaPropia.h"
#include "llibreriaExercici.h"

void mostrarResultat(int contadors[], int qtt)
{
    for (int i = MINNUM; i < qtt ; i++)
    {
        if (contadors[i] > 0)
        {
            printf("[%d]:%d\n", i, contadors[i]);
        }
    }
}